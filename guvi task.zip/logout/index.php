<?php
session_name('KREA_ALUMNI');
session_start();
session_destroy();
header('location:../');
?>

