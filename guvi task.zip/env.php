<?php
// session_start();

define('MAIN_BASE_URL', 'http://localhost/guvi%20task');
//define('MAIN_BASE_URL', 'https://gsbalumni.krea.edu.in/');//Live
//define('MAIN_BASE_URL', 'https://test-gsbalumni.krea.edu.in/');//test server
define('file_up_path', 'C:/wamp64/www/guvi%20task');
//define('file_up_path', '/home/u253658055/domains/test-gsbalumni.krea.edu.in/public_html/');//test
//efine('file_up_path', '/home/u253658055/domains/gsbalumni.krea.edu.in/public_html/');//Live server
define("GSIGN_CLIENT_ID","650772966174-g5aahras5kdsa1f4ht36ohnpguomdja1.apps.googleusercontent.com");//local
//define("GSIGN_CLIENT_ID","436891906328-jbnuss9fem68ui2iffmtukqlqpd2modb.apps.googleusercontent.com");//live



 define('DB_SERVER', 'localhost');
 define('DB_USERNAME', 'root');
 define('DB_PASSWORD', '');
 define('DB_DATABASE', 'gsb_alumni_new_db');
 define('DB_DATABASE2', 'gsb_alumni_new_db');

// define('DB_PORT', '3306');
//Live Gcp server
// define('DB_SERVER', '172.17.0.1');
// define('DB_USERNAME', 'root');
// define('DB_PASSWORD', 'IlovekreaAlumini@005@123');
// define('DB_DATABASE', 'gsb_alumni_db');
// define('DB_DATABASE2', 'gsb_alumni_db');
// define('DB_PORT', '6000');
//Live Hostinger server
// define('DB_SERVER', 'hostinger.krea.edu.in');
//define('DB_SERVER', 'localhost');
//define('DB_USERNAME', 'u253658055_gsbalumni');
//define('DB_PASSWORD', 'Rfa!!q#q64s8-yGUqB');
//define('DB_DATABASE', 'u253658055_gsbalumni');
//define('DB_DATABASE2', 'u253658055_gsbalumni');
define('DB_PORT', '3306');


//define('DB_SERVER', 'localhost');
//define('DB_USERNAME', 'u253658055_test_gsbalumni');
//define('DB_PASSWORD', 'TT9AJeWG&3u');
//define('DB_DATABASE', 'u253658055_test_gsbalumni');
//define('DB_DATABASE2', 'u253658055_test_gsbalumni');
//define('DB_PORT', '3306');

define("website_path","website link");
//define("file_up_path","C:/wamp64/www/job_posting/alumniportal/");



?>