<footer style="padding-bottom: 0px;">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="about-veno">
                    <div class="logo">
                        <img src="<?php echo MAIN_BASE_URL;?>/uploads/guvi-logo.png" alt="Logo" style="width: 50%;">
                    </div>
                     <p>...</p>
<!--                    <ul class="social-icons">-->
<!--                        <li>-->
<!--                            <a href="https://www.facebook.com/groups/ifmrgsbofficialalumnigroup/"><i class="fa fa-facebook"></i></a>-->
<!--                            <a href="https://instagram.com/ifmr_gsb_sricity"><i class="fa fa-instagram"></i></a>-->
<!--                            <a href="https://youtube.com/channel/UCAjwb2trX_m_6hobx02MV9g"><i class="fa fa-youtube"></i></a>-->
<!--                            <a href="https://www.linkedin.com/school/ifmrgsb"><i class="fa fa-linkedin"></i></a>-->
<!--                        </li>-->
<!--                    </ul>-->
                </div>
            </div>
        </div>
    </div>


    <div class="sub-footer">
        <p>Copyright © 2022 GUVI - All rights reserved </p>
    </div>

    <script src="<?php echo MAIN_BASE_URL;?>/assets/js/core/popper.min.js"></script>
    <script src="<?php echo MAIN_BASE_URL;?>/assets/js/core/bootstrap.min.js"></script>


</footer>

</div>



</body>
</html>
